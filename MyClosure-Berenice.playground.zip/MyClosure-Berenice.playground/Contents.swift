import UIKit

var str = "Hello, playground"


var multiplication : (Int, Int) -> Int = {(number1, number2) in
    return  number1 + number2
}
multiplication(12, 12)
print("the answer to the problem is: \(multiplication(12, 12))")


